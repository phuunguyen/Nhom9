function validateForm() {
	if(validateUsername() & validateDes() & validatePrice()){
		return true;
	}else{
		return false;
	}
}

function validateForm1() {
	if(validateManuName()){
		return true;
	}else{
		return false;
	}
}

function validateManuName(){
	var field = $('#manu_name').val();
	var filter = /^.{6,}$/;
	if(filter.test(field) == false){
		$('#manu_name').parent().parent().addClass('has-error');
		$('#manu_name').next().css("color","red").html('Chưa nhập manu_name');
		return false;
	}else
	{
		$('#manu_name').parent().parent().removeClass('has-error');
		$('#manu_name').next().html('');
		return true;
	}
}

function validateUsername(){
	var field = $('#name').val();
	var filter = /^.{6,}$/;
	if(filter.test(field) == false){
		$('#name').parent().parent().addClass('has-error');
		$('#name').next().css("color","red").html('Chưa nhập sản phẩm');
		return false;
	}else
	{
		$('#name').parent().parent().removeClass('has-error');
		$('#name').next().html('');
		return true;
	}
}
function validateDes(){
	var field = $('#description').val();
	var filter = /^.{1,}$/;
	if(filter.test(field) == false){
		$('#description').parent().parent().addClass('has-error');
		$('#description').next().css("color","red").html('Chưa nhập mô tả');
		return false;
	}else
	{
		$('#description').parent().parent().removeClass('has-error');
		$('#description').next().html('');
		return true;
	}
}
function validatePrice(){
	var field = $('#price').val();
	var filter = /^.{6,}$/;
	if(filter.test(field) == false){
		$('#price').parent().parent().addClass('has-error');
		$('#price').next().css("color","red").html('Chưa nhập giá');
		return false;
	}else
	{
		$('#price').parent().parent().removeClass('has-error');
		$('#price').next().html('');
		return true;
	}
}