<?php
/*
require "config.php";
require "db.php";
$db = new Db;
$login = $db->getUser_pass();
foreach ($login as $value) {
	echo $value['username'];
	echo $value['password'];
}*/
// class User{
// 	public $username;
// 	public $password;
// 	public function __construct($username,$password){
// 		$this->username = $username;
// 		$this->password = password_hash($password,PASSWORD_DEFAULT);
// 	}
// 	public function getFullName(){
// 		return $this->firstName.$this->lastName;
// 	}
// 	public function getUsername(){
// 		return $this->username;
// 	}
// 	// public function login($username,$password){
// 	// 	$hash = password_hash("12345",PASSWORD_DEFAULT);
// 	// 	foreach ($login as $value) {
// 	// 		if($username== $value['username'] && $password = $value['password']){
// 	// 			return true;
// 	// 			break;
// 	// 		}
// 	// 	}
// 	// }
}
