<?php
class Db{
	public static $conn, $key;

	public function __construct(){
		self::$conn = new mysqli(DB_HOST,DB_USER,DB_PASS,DB_NAME);
		self::$conn->set_charset('utf8');
	}
	public function __destruct(){
		self::$conn->close();
	}

	public function getData($obj){
		$arr = array();
		while($row = $obj->fetch_assoc()){
			$arr[]=$row;
		}
		return $arr;
	}

	//lay password va username
	public function getUser_pass(){
		$sql = "SELECT username, password FROM `login`";
		$result = self::$conn->query($sql);
		return $this->getdata($result);
	}

	//tra ve tat ca san pham
	public function product1(){
		$sql = "SELECT * FROM `products`, `manufactures`, `protypes` WHERE manufactures.manu_ID = products.manu_id AND protypes.type_id = products.type_id";
		$result = self::$conn->query($sql);
		return $this->getdata($result);
	}
	//tra ve thong tin hang san xuat
	public function manufactures(){
		$sql = "SELECT * FROM  `manufactures`";
		$result = self::$conn->query($sql);
		return $this->getdata($result);
	}

	//tim kiem san pham
	public function product2(){
		if(isset($_GET['key']))
		{
			$key = $_GET['key'];
		}
		$sql = "SELECT * FROM `products`, `manufactures`, `protypes` WHERE manufactures.manu_ID = products.manu_id AND protypes.type_id = products.type_id AND Name LIKE '%".$key."%'";
		$result = self::$conn->query($sql);
		return $this->getdata($result);	
	}

	//tim kiem hang san xuat
	public function findManufacture(){
		if(isset($_GET['key']))
		{
			$key = $_GET['key'];
		}
		$sql = "SELECT * FROM `manufactures` WHERE manu_name LIKE '%".$key."%'";
		$result = self::$conn->query($sql);
		return $this->getdata($result);	
	}

	//tra ve san pham
	public function getAllProduct($page, $per_page){
		$first_link = ($page -1) * $per_page;	
		$sql = "SELECT * FROM `products`, `manufactures`, `protypes` WHERE manufactures.manu_ID = products.manu_id AND protypes.type_id = products.type_id LIMIT $first_link, $per_page";
		$result = self::$conn->query($sql);
		return $this->getdata($result);	
	}

	//phan trang

	public function paginate1($url, $total, $page, $per_page, $offset)
	{
		if($total <= 0) {
			return "";
		}
		$total_links = ceil($total/$per_page);
		if($total_links <= 1) {
			return "";
		 }
		$from = $page - $offset;
		$to = $page + $offset;
		//$offset qui định số lượng link hiển thị ở 2 bên trang hiện hành
		//$offset = 2 và $page = 5,lúc này thanh phân trang sẽ hiển thị: 3 4 5 6 7
		if($from <= 0) {
			$from = 1;
			$to = $offset * 2;
		}
		if($to > $total_links) {
			$to = $total_links;
		}
		$link = "";
		for ($j = $from; $j <= $to; $j++) {
			$link = $link."<a href = '$url?page=$j'> $j </a>";
		}
		return $link;
	}
	//them san pham
	public function addProduct($name,$image,$description,$price,$manu_id,$type_id){
		//lay du lieu sql
		if (isset($_POST['name'])) {
			$name = $_POST['name'];
			$image = $_FILES["fileToUpload"]["name"];
			$description = $_POST['description'];
			$price = $_POST['price'];
			$manu_id = $_POST['manu_id'];
			$type_id = $_POST['type_id'];
		}
		$sql = "INSERT INTO products (name,image,description,price,manu_id,type_id) VALUES ('$name','$image','$description','$price',$manu_id,$type_id)";
		$result = self::$conn->query($sql);
		return $result;

	}
	//them hang san xuat
	public function addManufacture($manu_name,$manu_img){
		//lay du lieu sql
		if (isset($_POST['manu_name'])) {
			$manu_name = $_POST['manu_name'];
			$manu_img = $_FILES["fileToUpload"]["name"];
		}
		$sql = "INSERT INTO manufactures (manu_name,manu_img) VALUES ('$manu_name','$manu_img')";
		$result = self::$conn->query($sql);
		return $result;
	}
	//xoa san pham
	public function delete($ID)
	{
		$sql = "DELETE FROM `products` WHERE ID = $ID ";
		return self::$conn->query($sql);
	}

	//xoa hang san xuat
	public function deleteManufacture($manu_ID)
	{
		$sql = "DELETE FROM `manufactures` WHERE manu_ID = $manu_ID ";
		return self::$conn->query($sql);
	}

	//login
	public function login($user, $pass){
		//viet cau SQL
		$sql = "SELECT * FROM `login`";
		//thuc thi cau truy van
		$result = self::$conn->query($sql);
		$User = $this->getData($result);
		var_dump($User);
		foreach ($User as $value) {
			if ($value["user"] == $user && $pass == $value["pass"]){
				return true;
			}
		}
		return false;
	}
	//edit
	public function edit($ID){
		if(isset($_GET['ID']))
		{
			$ID = $_GET['ID'];
		}
		$sql = "SELECT * FROM `products`, `manufactures`, `protypes` WHERE manufactures.manu_ID = products.manu_id AND protypes.type_id = products.type_id AND ID = `$ID`";
		$result = self::$conn->query($sql);
		return $this->getData($result);

	}


}