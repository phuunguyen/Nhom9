<?php
require "config.php";
require "db.php";
if (isset($_POST['manu_name'])) {
	$manu_name = $_POST['manu_name'];
	$manu_img = $_FILES["fileToUpload"]["name"];
	
	$db = new Db;
	$add = $db->addManufacture($manu_name,$manu_img);
	//var_dump($add);
	$tagetDir = "public/images/";
	$tagetFile = $tagetDir.basename($_FILES["fileToUpload"]["name"]);
	$uploadOK = 1;
	$imageFileType = pathinfo($tagetFile,PATHINFO_EXTENSION);
	move_uploaded_file($_FILES["fileToUpload"]["tmp_name"],$tagetFile);
	if (isset($_POST["submit"])) {
		$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
		if ($check !== false) {
			echo "File is an image - ".$check["mine"];
			$uploadOK = 1;
		}
		else
		{
			echo "File is not an image.";
			$uploadOK = 0;
		}
	}
}
header("location: manufactures.php");